# Calculator In JS

### Introduction

This is a simple calculator which performs addition, subtraction, multiplication and division.

![Image of Calulator](https://i.imgur.com/YvBgb9s.png)

## Getting Started

1. Under the repository name, click Clone or download.
2. In the Clone with HTTPs section, click  to copy the clone URL for the repository.
3. Open Terminal.
4. Change the current working directory to the location where you want the cloned directory to be made.
5. Type `git clone`, and then paste the URL you copied in Step 2.
```
git clone git@github.com:aurobindodebnath/Calculator-in-JS.git 
```
6. Press Enter. Your local clone will be created.


## Acknowledgment 

Created by Aurobindo Debnath in Dec 2016




